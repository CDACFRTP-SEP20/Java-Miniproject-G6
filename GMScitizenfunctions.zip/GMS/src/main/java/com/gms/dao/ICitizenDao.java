package com.gms.dao;

import java.util.List;

import com.gms.model.Complaint;

public interface ICitizenDao {
	public int registerComplaint(Complaint complaint) throws Exception;
	public int getId(String username)throws Exception;
	public List<Complaint> getComplaints(int id) throws Exception;
}
